from abc import ABC, abstractmethod
from enum import Enum
import hashlib


def generate_unique_id_by_obj(obj):
    obj_str = str(obj)
    
    hash_object = hashlib.md5(obj_str.encode())
    
    return hash_object.hexdigest()


def generate_unique_id(*args):
    obj_str = "-".join([str(attr) for attr in args])
    
    hash_object = hashlib.md5(obj_str.encode())
    
    return hash_object.hexdigest()


class CustomEnum(Enum):

    @classmethod
    def from_value(cls, value):
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"{value} no es un valor válido de {cls.__name__}")


class PropertyState(CustomEnum):
    DISPONIBLE = 0
    ALQUILADO = 1
    RESERVADO = 2


class BusinessType(CustomEnum):
    GASTRONOMICO = 1
    MINORISTA = 2
    SERVICIO = 3
    ENTRETENIMIENTO = 4
    SALUD = 5
    TECNOLOGICO = 6
    ESPECIALIZADO = 7
    EDUCATIVO = 8


class Property(ABC):
    
    def __init__(
        self, 
        location: str, 
        rooms: int, 
        surface: float, 
        state: PropertyState,
        cost: float = None,
        tenant: str = None
        ):
        self.__location = location
        self.__rooms = rooms
        self.__surface = surface
        self.__state = state
        self.__cost = cost
        self.__tenant = tenant
        self.__identifier = generate_unique_id(
            self.__class__.__name__,
            self.location,
            self.rooms,
            self.surface,
            self.state.name
        )

    @property
    def identifier(self):
        return self.__identifier

    @identifier.setter
    def identifier(self, identifier):
        self.__identifier = identifier

    @property
    def location(self):
        return self.__location

    @location.setter
    def location(self, location):
        self.__location = location

    @property
    def rooms(self):
        return self.__rooms

    @rooms.setter
    def rooms(self, rooms):
        self.__rooms = rooms

    @property
    def surface(self):
        return self.__surface

    @surface.setter
    def surface(self, surface):
        self.__surface = surface

    @property
    def state(self):
        return self.__state

    @state.setter
    def state(self, state):
        self.__state = state

    @property
    def cost(self):
        return self.__cost

    @cost.setter
    def cost(self, cost):
        self.__cost = cost

    @property
    def tenant(self):
        return self.__tenant

    @tenant.setter
    def tenant(self, tenant):
        self.__tenant = tenant  

    def __str__(self):
        return f"""
        - Ubicación: {self.__location}
        - Ambientes: {self.__rooms}
        - Superficie: {self.__surface}
        - Estado: {self.__state.name}"""


class Apartment(Property):

    def __init__(
        self, 
        location: str, 
        rooms: int, 
        surface: float, 
        state: PropertyState,
        cost: float = None,
        tenant: str = None,
        floor: int = 1, 
        number: str = "A", 
        balcony: bool = False
        ):
        super().__init__(location, rooms, surface, state, cost, tenant)
        self.__floor = floor
        self.__number = number
        self.__balcony = balcony

    @property
    def floor(self):
        return self.__floor

    @property
    def number(self):
        return self.__number

    @property
    def balcony(self):
        return self.__balcony
        
    def __str__(self):
        estate_data = super().__str__()
        return f"""\
        {estate_data}
        - Piso: {self.__floor}
        - Número de departamento: {self.__number}
        - Tiene balcón: {self.__balcony}
        """


class House(Property):
    
    def __init__(
        self, 
        location: str, 
        rooms: int, 
        surface: float, 
        state: PropertyState,
        cost: float = None,
        tenant: str = None,
        garden: bool = False
        ):
        super().__init__(location, rooms, surface, state, cost, tenant)
        self.__garden = garden
        

    @property
    def garden(self):
        return self.__garden

    def __str__(self):
        estate_data = super().__str__()
        return f"""
        {estate_data}
        - Tiene jardín: {self.__garden}
        """


class Shop(Property):
    
    def __init__(
        self, 
        location: str, 
        rooms: int, 
        surface: float, 
        state: PropertyState,
        cost: float = None,
        tenant: str = None,
        type: BusinessType = BusinessType.MINORISTA
        ):
        super().__init__(location, rooms, surface, state, cost, tenant)
        self.__type = type

    @property
    def business_type(self):
        return self.__type


    def __str__(self):
        estate_data = super().__str__()
        return f"""\
        {estate_data}
        - Tipo de negocio: {self.__type.name}
        """