from properties import Property, Apartment, House, Shop, PropertyState, BusinessType
from storage import JSONStorage
from custom_logging import logger


DATA_FILE = 'inmobiliaria.json'


class PropertyManager:

    def __init__(self):
        self.__catalog: list[Property] = list()
        self.__storage = JSONStorage(DATA_FILE)

    @property
    def catalog(self):
        return self.__catalog

    @property
    def storage(self):
        return self.__storage

    def create_property(
        self, 
        *,
        property_type,
        location, 
        rooms, 
        surface, 
        state, 
        cost=None, 
        tenant=None,
        floor=None,
        number=None,
        balcony=None,
        garden=None,
        business_type=None
        ):
        if property_type == "Departamento":
            estate = Apartment(
                location=location, 
                rooms=rooms, 
                surface=surface, 
                state=state, 
                cost=cost, 
                tenant=tenant,
                floor=floor,
                number=number,
                balcony=balcony
            )
        elif property_type == "Casa":
            estate = House(
                location=location, 
                rooms=rooms, 
                surface=surface, 
                state=state, 
                cost=cost, 
                tenant=tenant,
                garden=garden
            )
        elif property_type == "Negocio":
            estate = Shop(
                location=location, 
                rooms=rooms, 
                surface=surface, 
                state=state, 
                cost=cost, 
                tenant=tenant,
                type=business_type
            )
        logger.info(f"Creando propiedad {property_type}: {estate}")        

        return estate

    def add_property(self, estate: Property):
        logger.info(f"Agregando nueva propiedad: {estate}")
        self.catalog.append(estate)
        self.__save_property(estate)

    def __save_property(self, estate: Property):
        data = self.storage.load_data()
        property_id = estate.identifier
        data[property_id] = {
            'type': estate.__class__.__name__,
            'location': estate.location, 
            'rooms': estate.rooms, 
            'surface': estate.surface, 
            'state': estate.state.value, 
            'cost': estate.cost, 
            'tenant': estate.tenant,
            'floor': estate.floor if hasattr(estate, 'floor') else None,
            'number': estate.number if hasattr(estate, 'number') else None,
            'balcony': estate.balcony if hasattr(estate, 'balcony') else None,
            'garden': estate.garden if hasattr(estate, 'garden') else None,
            'business_type': estate.business_type.value if hasattr(estate, 'business_type') else None,
        }
        self.storage.save_data(data)

    def remove_property(self, property_id):
        estate = self.catalog[property_id]
        logger.info(f"Eliminando propiedad: {estate}")
        self.__delete_property(estate)
        del self.catalog[property_id]

    def __delete_property(self, estate: Property):
        data = self.storage.load_data()
        property_id = estate.identifier
        del data[property_id]
        self.storage.save_data(data)

    def load_data(self):
        property_map = {
            "Apartment": "Departamento",
            "House": "Casa",
            "Shop": "Negocio"
        }
        data = self.storage.load_data()
        for k, v in data.items():
            property_type_value = property_map.get(v.get('type'))
            estate = self.create_property(
                property_type=property_type_value,
                location=v.get('location'), 
                rooms=v.get('rooms'), 
                surface=v.get('surface'), 
                state=PropertyState.from_value(v.get('state')),
                cost=v.get('cost'), 
                tenant=v.get('tenant'),
                floor=v.get('floor') if property_type_value=="Departamento" else None,
                number=v.get('number') if property_type_value=="Departamento" else None,
                balcony=v.get('balcony') if property_type_value=="Departamento" else None,
                garden=v.get('garden') if property_type_value=="Casa" else None,
                business_type=BusinessType.from_value(v.get('business_type')) if property_type_value=="Negocio" else None
            )
            self.catalog.append(estate)

    def update_property(self, property_identifier, estate):
        logger.info(f"Propiedad a editar: {property_identifier}")
        self.__save_property(estate)
