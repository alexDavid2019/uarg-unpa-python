import json
from pathlib import Path
from custom_logging import logger


class JSONStorage:

    def __init__(self, file_path: str):
        self.__file_path = file_path

    @property
    def file_path(self):
        return self.__file_path

    def save_data(self, data: dict):
        logger.info(f"Guardando datos en {self.file_path}")
        with open(self.file_path, 'w') as f:
            json.dump(data, f, indent=4)

    def load_data(self):
        logger.info(f"Cargando datos desde {self.file_path}")
        data = {}
        file = Path(self.file_path)
        if file.exists():
            with open(self.file_path, 'r') as f:
                try:
                    data = json.load(f)
                except json.JSONDecodeError as e:
                    logger.error(f"Error al abrir archivo JSON: {e}")
        else:
            logger.info(f"No hay archivo de datos. Creando uno vacío.")
        
        return data
