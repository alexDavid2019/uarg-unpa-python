'''
CONSIGNA:
    Una inmobiliaria necesita una aplicación para llevar un registro de sus propiedades.
    Para cada una se debe saber:
    - Ubicación
    - Cantidad de ambientes
    - Metros cuadrados    

    Las propiedades pueden ser: casa, departamento o local comercial.
    Para los departamentos se necesita saber: piso, departamento y si tiene balcón o no.
    Para los locales comerciales se necesita saber, solo si están disponibles, el tipo de negocio que se maneja:
    gastronómico, minorista, servicio, entretenimiento, salud, tecnológico, especializado, educativo.

    Para cada una se debe saber si están disponibles o alquiladas. En caso de estar alquiladas, 
    se debe incluir el costo de alquiler mensual y el nombre del inquilino.

    Se debe poder cargar, editar, eliminar y buscar propiedades.
    También se debe poder mostrar el catálogo completo
'''
'''
# MODELO
Dudas:
- Ubicación: Calle y número
- Por qué valores se busca: estado, tipo, ambiente y ubicación
- Borrar: mostrando lista y seleccionando valor

Clases:
Propiedad -> Casa, Departamento, LocalComercial
- ubicacion: str
- ambientes: int
- superficie: float
- estado: Enum

Acciones:
- Cargar
- Editar
- Eliminar
- Buscar
- Mostrar catálogo

'''
from ui import GraphicalUserInterface, CommandLineUserInterface
from managers import PropertyManager
from aux import populate_catalog
import sys
from custom_logging import logger


CLI_MODE = "cli"
GUI_MODE = "gui"
HELP = "help"


def launch_gui(manager):
    logger.info("Abriendo aplicación en modo interfaz gráfica")
    ui = GraphicalUserInterface(manager)
    ui.launch()


def launch_cli(manager):
    logger.info("Abriendo aplicación en modo línea de comando")
    ui = CommandLineUserInterface(manager)
    ui.launch()


def show_help():
    help_text = """
    AIPython II - Inmobiliaria
    --------------------------
    
    Aplicación para llevar registro de propiedades gestionadas por
    una inmobiliaria.
    
    Modos de ejecución:
    python main.py cli - Ejecución de interfaz de línea de comandos.
    python main.py gui - Ejecución de interfaz gráfica.
    python main.py help - Menú de ayuda
    """
    print(help_text)


def main():
    manager = PropertyManager()
    # populate_catalog(manager)
    manager.load_data()

    arguments = sys.argv
    no_arguments_passed = len(arguments) == 1
    if no_arguments_passed:
        launch_gui(manager)
    else:
        mode = arguments[1]
        if mode == CLI_MODE:
            launch_cli(manager)
        elif mode == GUI_MODE:
            launch_gui(manager)
        elif mode == HELP:
            show_help()
        else:
            print(f"Modo no válido. Opciones disponibles: cli o gui")
            show_help()

if __name__ == "__main__":
    logger.info("Inicializando AIPython II - Inmobiliaria")
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Saliendo de aplicación AIPython II - Inmobiliaria")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Ha ocurrido un error inesperado: {e}")
        sys.exit(1)

