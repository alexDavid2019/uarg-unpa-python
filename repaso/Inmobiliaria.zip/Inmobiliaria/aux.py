from managers import PropertyManager
from properties import Apartment, House, Shop, PropertyState, BusinessType

def populate_catalog(manager: PropertyManager):
    p1 = Apartment(
        location="San Martín 123",
        rooms=2,
        surface=30.0,
        state=PropertyState.DISPONIBLE,
        floor=1,
        number="2D",
        balcony=False
    )
    manager.add_property(p1)
    p2 = House(
        location="Roca 123",
        rooms=4,
        surface=60.0,
        state=PropertyState.DISPONIBLE,
        garden=True
    )
    manager.add_property(p2)
    p3 = Shop(
        location="Zapiola 123",
        rooms=3,
        surface=40.0,
        state=PropertyState.ALQUILADO,
        cost=420.000,
        tenant="Juanito Perez",
        type=BusinessType.GASTRONOMICO
    )
    manager.add_property(p3)
    p4 = House(
        location="Urquiza 123",
        rooms=2,
        surface=20.0,
        state=PropertyState.ALQUILADO,
        cost=10.000,
        tenant="José Lopez",
        garden=True
    )
    manager.add_property(p4)