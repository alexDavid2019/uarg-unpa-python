from tkinter import (
    messagebox, Tk, Frame, Label, TOP, BOTH, LEFT, Entry, Button, X, ttk, BOTTOM, Toplevel,
    StringVar, IntVar, DoubleVar, BooleanVar, Checkbutton
)
from abc import ABC, abstractmethod
from properties import Apartment, House, Shop, BusinessType, PropertyState

APP_FONT = "Cantarell"


class UserInterface(ABC):

    def __init__(self, property_manager):
        self.__property_manager = property_manager

    @property
    def property_manager(self):
        return self.__property_manager

    @abstractmethod
    def launch(self):
        pass


class CommandLineUserInterface(UserInterface):

    def show_menu(self):
        """
        Display options menu.
        """
        menu = '''
    Menú:
    1 - Cargar
    2 - Editar
    3 - Eliminar
    4 - Buscar
    5 - Mostrar catálogo

    Ingrese 0 para salir
        '''
        print(menu)


    def show_welcome_message(self):
        """Display welcome message"""
        message = '''
    #=========================================================#
    #           AIPython 2 - Ejemplo 2: Inmobiliaria          #  
    #           ----------------------------------            #
    #=========================================================#
        '''
        print(message)

    def launch(self):
        self.show_welcome_message()

        self.show_menu()
        while (choice := input("Seleccione una opción: ")) != "0":
            if choice == "1":
                print("Opción seleccionada: Cargar")
                self.__add_property()
            elif choice == "2":
                print("Opción seleccionada: Editar")
            elif choice == "3":
                print("Opción seleccionada: Eliminar")
                self.__remove_property()
            elif choice == "4":
                print("Opción seleccionada: Buscar")
            elif choice == "5":
                print("Opción seleccionada: Mostrar catálogo")
                self.__show_properties()
            else:
                print("¡Ups! La opción ingresada no es válida. Intente nuevamente.")
            
            self.show_menu()

        print("Gracias por utilizar la aplicación de inmobiliaria. ¡Vuelva pronto!")

    def __add_property(self):
        property_types = ["Departamento", "Casa", "Negocio"]
        self.__show_add_property_type_menu()
        while (choice := input("Ingrese el número de la opción deseada: ")) not in [str(num) for num in range(4)]:
            print("La opción seleccionada no es válida.")
            self.__show_add_property_type_menu()
        
        if choice == "1":
            self.__add_apartment()
        elif choice == "2":
            self.__add_house()
        elif choice == "3":
            self.__add_shop()

    def __show_add_property_type_menu(self):
        menu = """
        Seleccione el tipo de propiedad que quiere cargar:
        1 - Departamento
        2 - Casa
        3 - Negocio

        0 - Cancelar
        """
        print(menu)

    def __add_apartment(self):
        location, rooms, surface, state, cost, tenant = self.__read_common_fields()
        floor = input("Ingrese el piso: ")
        number = input("Ingrese el número de departamento: ")
        while (balcony_value := input("Indique si tiene balcón (si/no): ")) not in ["si", "no"]:
            print("La opción ingresada no es válida. Indique 'si' o 'no'")

        balcony = True if balcony_value == "si" else False

        estate = self.property_manager.create_property(
            property_type="Departamento",
            location=location,
            rooms=rooms,
            surface=surface,
            state=state,
            cost=cost,
            tenant=tenant,
            floor=floor,
            number=number,
            balcony=balcony,
        )
        self.property_manager.add_property(estate)
        print(f"Propiedad agregada con éxito!")

    def __add_house(self):
        pass

    def __add_shop(self):
        pass

    def __read_common_fields(self):
        location = input("Ingrese la ubicación: ")
        rooms = input("Ingrese la cantidad de ambientes: ")
        surface = input("Ingrese la superficie (m2): ")
        
        while (state_choice := input("Seleccione un estado: \n0 - Disponible\n1 - Alquilado\n2 - Reservado\n")) not in [str(num) for num in range(4)]:
            print(f"El estado seleccionado no es válido.")
        
        state = PropertyState.from_value(int(state_choice))
        if state == PropertyState.ALQUILADO:
            cost = input("Ingrese el costo de alquiler: ")
            tenant = input("Ingrese el nombre del inquilino: ")
        else:
            cost = None
            tenant = None

        return location, rooms, surface, state, cost, tenant

    def __remove_property(self):
        self.__show_properties()
        while (choice := int(input("Seleccione elemento a eliminar: "))) > len(self.property_manager.catalog):
            print(f"El id ingresado no es válido.")
        self.property_manager.remove_property(choice)
        print("¡Propiedad eliminada exitosamente!")

    def __show_properties(self):
        for i, estate in enumerate(self.property_manager.catalog):
            print(f"{i} - Tipo de propiedad: {estate.__class__.__name__}\n{estate}")


class GraphicalUserInterface(UserInterface):

    def __init__(self, property_manager):
        super().__init__(property_manager)
        self.__root = Tk()
        self.__table_frame = Frame(self.__root)
        self.__properties_tree = ttk.Treeview(master=self.__table_frame)

    @property
    def root(self):
        return self.__root

    @property
    def table_frame(self):
        return self.__table_frame

    @property
    def properties_tree(self):
        return self.__properties_tree

    @properties_tree.setter
    def properties_tree(self, properties_tree):
        self.__properties_tree = properties_tree

    def launch(self):
        """
        Abre la interfaz de usuario que permite interactuar con el programa.
        """
        self.root.geometry("900x900")
        self.__add_title()
        self.__add_presentation()                                                  
        self.__handle_property_form()
        self.__add_properties_table()
        self.__add_delete_form()
        self.__add_edit_button()
        self.__add_exit_button()
        self.root.protocol('WM_DELETE_WINDOW', lambda: self.exit_confirmation_message())
        self.root.mainloop()

    def __add_title(self):
        """
        Muestra el título de la aplicación en la interfaz gráfica
        """
        self.root.title("AIPython II - Inmobiliaria")
        
    def __add_presentation(self):
        """
        Agrega texto de presentación a la interfaz gráfica
        """
        presentation_text = """
        Bienvenido al registro de inmobiliaria. 
        Esta aplicación le permitirá agregar, buscar, modificar y eliminar propiedades.
        """
        header_frame = Frame(self.root)
        header = Label(master=header_frame, text="Registro de propiedades", fg="gray", bg="#212121", font=(APP_FONT, 20))
        header.pack(side=TOP, fill=BOTH, ipady=10)
        presentation = Label(master=header_frame, text=presentation_text, font=(APP_FONT, 12))
        presentation.pack()
        header_frame.pack(side=TOP, fill=BOTH) 

    def exit_confirmation_message(self):
        response = messagebox.askyesno('Abandonar aplicación', '¿Está seguro de que desea salir de la aplicación?')
        if response:
            self.root.destroy()

    def __add_properties_table(self):
        self.table_frame.pack(fill=BOTH, expand=True)

        columns = ("Type", "Location", "Rooms", "Surface", "State", "Cost", "Tenant")
        self.properties_tree = ttk.Treeview(self.table_frame, columns=columns, show='headings')
        
        self.properties_tree.heading("Type", text="Tipo")
        self.properties_tree.heading("Location", text="Ubicación")
        self.properties_tree.heading("Rooms", text="Ambientes")
        self.properties_tree.heading("Surface", text="Superficie")
        self.properties_tree.heading("State", text="Estado")
        self.properties_tree.heading("Cost", text="Costo")
        self.properties_tree.heading("Tenant", text="Inquilino")

        for col in columns:
            self.properties_tree.column(col, anchor="center", width=100)

        self.properties_tree.column("Location", width=200, anchor="w")
        self.properties_tree.column("Cost", anchor="e")

        self.insert_properties_in_table()

        vsb = ttk.Scrollbar(self.table_frame, orient="vertical", command=self.properties_tree.yview)
        vsb.pack(side='right', fill='y')
        hsb = ttk.Scrollbar(self.table_frame, orient="horizontal", command=self.properties_tree.xview)
        hsb.pack(side='bottom', fill='x')

        self.properties_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.properties_tree.pack(expand=True, fill='both')

        self.properties_tree.bind("<Double-1>", self.on_property_double_click)

    def insert_properties_in_table(self):
        for index, prop in enumerate(self.property_manager.catalog, start=1):
            values = [
                prop.__class__.__name__,
                prop.location,
                prop.rooms,
                f"{prop.surface} m2",
                prop.state.name,
                f"${prop.cost:.2f}" if prop.cost else "N/D",
                prop.tenant or "N/D"
            ]
            self.properties_tree.insert("", "end", iid=str(index), text=str(index), values=values)

    def on_property_double_click(self, event):
        item = self.properties_tree.selection()[0]
        property_values = self.properties_tree.item(item, 'values')
        property_index = int(self.properties_tree.item(item)['text']) - 1
        
        selected_property = self.property_manager.catalog[property_index]
        
        detail_window = Toplevel(self.root)
        detail_window.title("Detalle de la propiedad")
        detail_window.geometry("300x500")

        detail_frame = Frame(detail_window)
        detail_frame.pack(padx=10, pady=10, fill=BOTH, expand=True)

        def create_label(master, text, value):
            Label(master, text=text, font=(APP_FONT, 10, 'bold')).pack(anchor="w")
            Label(master, text=value, wraplength=280).pack(anchor="w")

        create_label(detail_frame, "Tipo:", selected_property.__class__.__name__)
        create_label(detail_frame, "Ubicación:", selected_property.location)
        create_label(detail_frame, "Ambientes:", selected_property.rooms)
        create_label(detail_frame, "Superficie:", f"{selected_property.surface} sqm")
        create_label(detail_frame, "Estado:", selected_property.state.name)
        create_label(detail_frame, "Costo:", f"${selected_property.cost:.2f}" if selected_property.cost else "N/A")
        create_label(detail_frame, "Inquilino:", selected_property.tenant or "None")

        if isinstance(selected_property, Apartment):
            create_label(detail_frame, "Piso:", selected_property.floor)
            create_label(detail_frame, "Numero:", selected_property.number)
            create_label(detail_frame, "Tiene balcón:", selected_property.balcony)
        elif isinstance(selected_property, House):
            create_label(detail_frame, "Tiene jardín:", selected_property.garden)
        elif isinstance(selected_property, Shop):
            create_label(detail_frame, "Tipo de negocio:", selected_property.business_type.name)

        Button(detail_window, text="Cerrar", command=detail_window.destroy).pack(pady=10)

    def refersh_properties_tree(self):
       """
       Actualiza la lista de propiedades en la tabla de la interfaz gráfica.
       """
       properties_table = self.properties_tree.get_children()
       for estate in properties_table:
           self.properties_tree.delete(estate)

       self.insert_properties_in_table()

    def __handle_property_form(self):
        """
        Agrega un formulario para cargar detalles de una nueva propiedad.
        """
        form_frame = Frame(self.root)
        label_width = 15
        entry_width = 25
        
        location_input = StringVar()
        rooms_input = IntVar()
        surface_input = DoubleVar()
        cost_input = DoubleVar()
        tenant_input = StringVar()

        property_type = StringVar(value="Departamento")
        property_types = ["Departamento", "Casa", "Negocio"]
        property_type_frame = Frame(form_frame)
        Label(property_type_frame, text="Tipo de propiedad", font=(APP_FONT, 12), width=label_width).pack(side=LEFT)
        property_type_combobox = ttk.Combobox(property_type_frame, textvariable=property_type, values=property_types, state="readonly")
        property_type_combobox.set("Departamento")
        property_type_combobox.pack(side=LEFT)
        property_type_frame.pack(side=TOP, ipady=5)

        state_input = StringVar(value=PropertyState.DISPONIBLE.name)
        state_input_frame = Frame(form_frame)
        Label(state_input_frame, text="Estado de propiedad", font=(APP_FONT, 12), width=label_width).pack(side=LEFT)
        state_input_combobox = ttk.Combobox(state_input_frame, textvariable=state_input, values=[state.name for state in PropertyState], state="readonly")
        state_input_combobox.set(PropertyState.DISPONIBLE.name) 
        state_input_combobox.pack(side=LEFT)
        state_input_frame.pack(side=TOP, ipady=5)

        common_fields = [
            ("Ubicación", location_input),
            ("Ambientes", rooms_input),
            ("Superficie (m2)", surface_input),
            ("Costo", cost_input),
            ("Inquilino", tenant_input)
        ]

        for field_name, field_var in common_fields:
            data_frame = Frame(form_frame)
            Label(data_frame, text=field_name, font=(APP_FONT, 12), width=label_width).pack(side=LEFT)
            Entry(data_frame, textvariable=field_var, width=entry_width).pack(side=LEFT)
            data_frame.pack(side=TOP, ipady=5, expand=True)

        floor_input = IntVar(value=1)
        number_input = StringVar(value="A")
        balcony_var = BooleanVar(value=False)
        garden_var = BooleanVar(value=False)
        business_type = StringVar(value="MINORISTA")

        additional_fields = {
            "Departamento": [
                ("Piso", floor_input),
                ("Número", number_input),
                ("Tiene balcón", balcony_var)
            ],
            "Casa": [
                ("Tiene jardín", garden_var)
            ],
            "Negocio": [
                ("Tipo de negocio", business_type)
            ]
        }

        def update_additional_fields(*args):
            for widget in form_frame.winfo_children():
                if widget not in [add_property_button.master, state_input_combobox.master, property_type_combobox.master, error_label.master]:
                    widget.destroy()

            for field_name, field_var in common_fields:
                data_frame = Frame(form_frame)
                Label(data_frame, text=field_name, font=(APP_FONT, 12), width=label_width).pack(side=LEFT)
                Entry(data_frame, textvariable=field_var, width=entry_width).pack(side=LEFT)
                data_frame.pack(side=TOP, ipady=5, expand=True)

            current_type = property_type.get()
            if current_type in additional_fields:
                for field_name, field_var in additional_fields[current_type]:
                    data_frame = Frame(form_frame)
                    if isinstance(field_var, BooleanVar):
                        Checkbutton(data_frame, text=field_name, variable=field_var).pack(side=LEFT)
                    else:
                        Label(data_frame, text=field_name, font=(APP_FONT, 12), width=label_width).pack(side=LEFT)
                        if field_name == "Tipo de negocio":
                            ttk.Combobox(data_frame, textvariable=business_type, values=[b.name for b in BusinessType]).pack(side=LEFT)
                        else:
                            Entry(data_frame, textvariable=field_var, width=entry_width).pack(side=LEFT)
                    data_frame.pack(side=TOP, ipady=5, expand=True)

            property_type_combobox.master.pack(side=TOP, ipady=5)

        property_type.trace('w', update_additional_fields)
        property_type_combobox.bind("<<ComboboxSelected>>", update_additional_fields)

        error_input = StringVar()
        error_label = Label(form_frame, textvariable=error_input, fg="red")
        error_label.pack(pady=5)

        def blank_form_fields():
            location_input.set("")
            rooms_input.set("1")
            surface_input.set("0.0")
            state_input.set(PropertyState.DISPONIBLE.name)
            cost_input.set("0.0")
            tenant_input.set("")
            floor_input.set("")
            number_input.set("")
            balcony_var.set(False)
            garden_var.set(False)

        def submit_form():
            try:
                property_type_value = property_type.get()
                state_value = PropertyState[state_input.get()]
                business_type_value = BusinessType[business_type.get()] if property_type_value=="Negocio" else None
                
                estate = self.property_manager.create_property(
                    property_type=property_type_value,
                    location=location_input.get(), 
                    rooms=rooms_input.get(), 
                    surface=surface_input.get(), 
                    state=state_value, 
                    cost=cost_input.get(), 
                    tenant=tenant_input.get(),
                    floor=floor_input.get() if property_type_value=="Departamento" else None,
                    number=number_input.get() if property_type_value=="Departamento" else None,
                    balcony=balcony_var.get() if property_type_value=="Departamento" else None,
                    garden=garden_var.get() if property_type_value=="Casa" else None,
                    business_type=business_type_value
                )
                
                self.property_manager.add_property(estate)
                
                blank_form_fields()
                update_additional_fields()
                messagebox.showinfo("Éxito", "Propiedad agregada con éxito.")

                self.refersh_properties_tree()
                
            except ValueError as ve:
                error_input.set(f"Error de valor: {ve}")
                messagebox.showerror("Error de Validación", f"Entrada no válida: {ve}")
            except Exception as e:
                error_input.set(str(e))
                messagebox.showerror("Error", f"Error al cargar propiedad: {e}")

        button_frame = Frame(form_frame)
        add_property_button = Button(button_frame, text="Agregar propiedad", command=submit_form)
        add_property_button.pack(pady=10)
        button_frame.pack(side=BOTTOM)

        update_additional_fields()

        form_frame.pack(expand=True)


    def __add_delete_form(self):

        def remove_property():
            table_selection = self.properties_tree.selection()
            if table_selection:
                selected_item = self.properties_tree.item(table_selection)
                property_id = selected_item.get('text')
                try:
                    self.property_manager.remove_property(int(property_id) - 1)

                    self.properties_tree.delete(table_selection)
                
                    messagebox.showinfo("Éxito", "Propiedad eliminada con éxito.")
                    self.refersh_properties_tree()
                except ValueError:
                    messagebox.showerror("Error", "ID de propiedad no válido.")
            else:
                messagebox.showwarning("Advertencia", "Seleccione una propiedad para eliminar.")
                
        remove_property_button = Button(
            master=self.root,
            text="Eliminar propiedad",
            command=lambda: remove_property()
            )
        remove_property_button.pack(side=LEFT, expand=True, ipady=10)


    def __add_exit_button(self):
        exit_button = Button(
            master=self.root,
            text="Salir de la aplicación",
            command=lambda: self.exit_confirmation_message()
            )
        exit_button.pack(side=LEFT, expand=True, ipady=10)


    def __add_edit_button(self):
        edit_button = Button(
            master=self.root,
            text="Editar propiedad",
            command=lambda: self.edit_property()
            )
        edit_button.pack(side=LEFT, expand=True, ipady=10)

    def edit_property(self):
        table_selection = self.properties_tree.selection()
        if table_selection:
            selected_item = self.properties_tree.item(table_selection)
            property_id = selected_item.get('text')
            try:
                elected_item = self.properties_tree.item(table_selection[0])
                property_id = int(selected_item['text']) - 1
                property_to_edit = self.property_manager.catalog[property_id]
                
                edit_window = Toplevel(self.root)
                edit_window.title("Editar Propiedad")
                edit_window.geometry("300x400")
                
                property_identifier = property_to_edit.identifier
                
                location_var = StringVar(value=property_to_edit.location)
                rooms_var = IntVar(value=property_to_edit.rooms)
                surface_var = DoubleVar(value=property_to_edit.surface)
                state_var = StringVar(value=property_to_edit.state.name)
                cost_var = DoubleVar(value=property_to_edit.cost if property_to_edit.cost else 0)
                tenant_var = StringVar(value=property_to_edit.tenant if property_to_edit.tenant else "")

                fields = [
                    ("Ubicación", location_var),
                    ("Ambientes", rooms_var),
                    ("Superficie (m2)", surface_var),
                    ("Estado", state_var),
                    ("Costo", cost_var),
                    ("Inquilino", tenant_var)
                ]

                frame = Frame(edit_window)
                for text, var in fields:
                    Label(frame, text=text).pack()
                    Entry(frame, textvariable=var).pack()
                frame.pack(pady=10)

                def save_changes():
                    try:
                        property_to_edit.location = location_var.get()
                        property_to_edit.rooms = rooms_var.get()
                        property_to_edit.surface = surface_var.get()
                        property_to_edit.state = PropertyState[state_var.get()]
                        if property_to_edit.state == PropertyState.ALQUILADO:
                            property_to_edit.cost = cost_var.get()
                            property_to_edit.tenant = tenant_var.get()
                        else:
                            property_to_edit.cost = None
                            property_to_edit.tenant = None
                        
                        self.property_manager.update_property(property_identifier, property_to_edit)
                        messagebox.showinfo("Éxito", "Propiedad editada con éxito.")
                        self.refersh_properties_tree()
                        edit_window.destroy()
                    except ValueError as e:
                        messagebox.showerror("Error", f"Entrada no válida: {e}")

                Button(edit_window, text="Guardar cambios", command=save_changes).pack(pady=10)

            except ValueError:
                messagebox.showerror("Error", "ID de propiedad no válido.")
        else:
            messagebox.showwarning("Advertencia", "Seleccione una propiedad para editar.")